var d,s,e=document,b=e.body;

// top left
d = e.createElement("div");
s = d.style;
s.backgroundImage = "url('borders/borders.png')";
s.display = "block";
s.position = "absolute";
s.left = "0px";
s.top = "0px";
s.width = "11px";
s.height = "327px";
s.zIndex = 2000;
b.appendChild(d);

d = e.createElement("div");
s = d.style;
s.backgroundImage = "url('borders/borders.png')";
s.display = "block";
s.position = "absolute";
s.left = "0px";
s.top = "0px";
s.width = "286px";
s.height = "11px";
s.zIndex = 2000;
b.appendChild(d);

// top right
d = e.createElement("div");
s = d.style;
s.backgroundImage = "url('borders/borders.png')";
s.backgroundPosition = "-51px -21px"
s.display = "block";
s.position = "absolute";
s.right = "0px";
s.top = "0px";
s.width = "286px";
s.height = "11px";
s.zIndex = 2000;
b.appendChild(d);

d = e.createElement("div");
s = d.style;
s.backgroundImage = "url('borders/borders.png')";
s.backgroundPosition = "-326px -21px";
s.display = "block";
s.position = "absolute";
s.right = "0px";
s.top = "0px";
s.width = "11px";
s.height = "166px";
s.zIndex = 2000;
b.appendChild(d);

// bottom left
d = e.createElement("div");
s = d.style;
s.backgroundImage = "url('borders/borders.png')";
s.backgroundPosition = "-31px -15px";
s.display = "block";
s.position = "absolute";
s.left = "0px";
s.bottom = "0px";
s.width = "11px";
s.height = "324px";
s.zIndex = 2000;
b.appendChild(d);

d = e.createElement("div");
s = d.style;
s.backgroundImage = "url('borders/borders.png')";
s.backgroundPosition = "-31px -330px";
s.display = "block";
s.position = "absolute";
s.left = "0px";
s.bottom = "0px";
s.width = "255px";
s.height = "9px";
s.zIndex = 2000;
b.appendChild(d);

// bottom right
d = document.createElement("div");
s = d.style;
s.backgroundImage = "url('borders/borders.png')";
s.backgroundPosition = "-336px -195px"
s.display = "block";
s.position = "absolute";
s.right = "0px";
s.bottom = "0px";
s.width = "11px";
s.height = "169px";
s.zIndex = 2000;
document.body.appendChild(d);

d = document.createElement("div");
s = d.style;
s.backgroundImage = "url('borders/borders.png')";
s.backgroundPosition = "-95px -356px"
s.display = "block";
s.position = "absolute";
s.right = "0px";
s.bottom = "0px";
s.width = "252px";
s.height = "8px";
s.zIndex = 2000;
document.body.appendChild(d);