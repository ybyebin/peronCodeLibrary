window.blockUI = function(){
  $(".ui-blocker").show();
};  
window.unblockUI = function(){
  $(".ui-blocker").hide();
};  
